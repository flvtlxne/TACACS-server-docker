These images are from https://uxwing.com ... the orignal docbook images seem
to be under GPL, and these ones are just free.

local name   | original name
-----------------------------------------------------
notes.svg    | round-information-outline-green-icon.svg
tip.svg      | pinned-icon.svg
caution.svg  | caution-icon.svg

