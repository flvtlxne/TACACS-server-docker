openssl req -x509 -newkey rsa:4096 -keyout demo.key -out demo.pem -sha256 -days 3650

