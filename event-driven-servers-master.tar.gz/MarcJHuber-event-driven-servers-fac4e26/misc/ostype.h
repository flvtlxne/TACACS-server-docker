/*
 * ostype.h
 * (C) 2001 Marc Huber <Marc.Huber@web.de>
 * All rights reserved.
 *
 * $Id: ostype.h,v 1.3 2005/12/31 12:14:23 huber Exp $
 *
 */

#ifndef __OSTYPE_H__
#define __OSTYPE_H__
char *ostype(void);
char *ostypef(char *, char *, size_t);
#endif				/* __OSTYPE_H__ */
