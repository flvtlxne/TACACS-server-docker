/* tokenize.h (C) 2000 Marc Huber <Marc.Huber@web.de>
 * All rights reserved.
 *
 * $Id: tokenize.h,v 1.3 2005/12/31 12:14:23 huber Exp $
 *
 */

#ifndef __TOKENIZE_H__
#define __TOKENIZE_H__
#include <sys/types.h>

int tokenize(char *, char **, int);
#endif				/* __TOKENIZE_H__ */
