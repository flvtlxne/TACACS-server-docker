#ifndef __MD5CRYPT_H__
#define __MD5CRYPT_H__
char *md5crypt(const char *, const char *);
#endif
