/*
 * h_pass.c
 * (C)1998-2011 by Marc Huber <Marc.Huber@web.de>
 *
 * $Id: 5ef52603c1bfd597e083430ea31326ede4d0a54e $
 *
 */

#include "headers.h"

static const char rcsid[] __attribute__((used)) = "$Id: 5ef52603c1bfd597e083430ea31326ede4d0a54e $";

void h_pass(struct context *ctx, char *arg)
{
    DebugIn(DEBUG_COMMAND);

    if (ctx->state == ST_user) {
	if (arg[0] == '-')
	    ctx->multiline_banners = 0;
	auth_mavis(ctx, arg);
    } else
	reply(ctx, MSG_503_USER_before_PASS);

    DebugOut(DEBUG_COMMAND);
}
