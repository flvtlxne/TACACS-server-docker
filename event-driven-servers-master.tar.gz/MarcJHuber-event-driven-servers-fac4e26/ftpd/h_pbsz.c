/*
 * h_pbsz.c
 *
 * (C)2000-2011 by Marc Huber <Marc.Huber@web.de>
 * All rights reserved.
 *
 * $Id: 19954dcb299df08ced6eb7f4675d8ae3963570c3 $
 *
 */

#include "headers.h"

static const char rcsid[] __attribute__((used)) = "$Id: 19954dcb299df08ced6eb7f4675d8ae3963570c3 $";

void h_pbsz(struct context *ctx, char *arg)
{
    unsigned pbs;

    DebugIn(DEBUG_COMMAND);

    if (!ctx->ssl_c)
	reply(ctx, MSG_503_Security_data_exchange_incomplete);
    else if (1 != sscanf(arg, "%u", &pbs))
	reply(ctx, MSG_501_Syntax_error);
    else {
	reply(ctx, "200 PBSZ=0\r\n");
	ctx->protected_buffer_size = 0;
    }
    DebugOut(DEBUG_COMMAND);
}
